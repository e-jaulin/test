param (
    [string]$packageName,
    [string]$optDepot,
    [string]$version
)

# Chemin de base vers le package SSIS et vers la bibliothèque newtonsoft
$workingDirectory = 'C:\00 - Projets\1 - Logistique\Atoptima\Packages SSIS\Atoptima_SSIS\'
$newtonsoftPath = 'C:\00 - Projets\1 - Logistique\Atoptima\Packages SSIS\Atoptima_SSIS\Newtonsoft.Json.dll'

# Initialiser le chemin vers le package SSIS :
# Premier package LOAD_XLS_FILES commun à tous
# Deuxième package LOAD_CSV_Files concaténé avec le num du dépot
# Troisième package INPUT_JSON_Archive_File concaténé avec le num du dépot

$ssisPackagePath = ''  
if ($packageName -eq "LOAD_XLS_FILES" -or $packageName -eq "PackageTest") {
    $ssisPackagePath = $workingDirectory + $packageName + '.dtsx'
} elseif ($packageName -eq "LOAD_CSV_Files" -or $packageName -eq "INPUT_JSON_Archive_File" -or $packageName -eq "LOAD_Commandes") {
    $ssisPackagePath = $workingDirectory + $packageName + '_'+$version+'_' + $optDepot + '.dtsx'
} else {
    $ssisPackagePath = $workingDirectory + $packageName + 'LOAD_XLS_FILES.dtsx'
}

# Chemin complet vers dtexec.exe 32 bits
$dtexecPath = 'E:\Program Files (x86)\Microsoft SQL Server\150\DTS\Binn\dtexec.exe'

# Vérifier si le chemin dtexec.exe existe
if (-Not (Test-Path $dtexecPath)) {
    Write-Error "Le fichier dtexec.exe n'a pas été trouvé à l'emplacement : $dtexecPath"
    exit 1
}

# Arguments pour la commande dtexec
$arguments = "/f `"$ssisPackagePath`""

# Exécuter la commande avec Start-Process et rediriger la sortie standard et l'erreur vers des fichiers temporaires
$outputFile = [System.IO.Path]::GetTempFileName()

# Exécuter le processus en redirigeant la sortie standard
$process = Start-Process -FilePath $dtexecPath -ArgumentList $arguments -NoNewWindow -Wait -RedirectStandardOutput $outputFile -PassThru -WorkingDirectory $workingDirectory

# Attendre que le processus se termine et lire la sortie des fichiers
$output = Get-Content $outputFile

# Afficher la sortie et l'erreur
Write-Output $output

# Supprimer les fichiers temporaires
Remove-Item $outputFile
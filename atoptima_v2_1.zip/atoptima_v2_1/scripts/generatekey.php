<?php

function generateApiKey($length = 32) {
    return bin2hex(random_bytes($length / 2));
}

// Générer une clé de 32 caractères
$apiKey = generateApiKey();
echo "Votre clé API : $apiKey";
?>
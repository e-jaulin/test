<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    header('Content-Type: application/json; charset=utf-8');

    if (isset($_POST['vehicle_uid'])) {        
        require_once "connexion.php";

        $vehicle_uid = $_POST['vehicle_uid'];

        // Requête SQL de mise à jour
        $sql = "
        UPDATE [BDT_ODS].[logistics].[".$TABLE_VEHICULE."]
        SET [DISPO] = CASE 
            WHEN [DISPO] = 'Oui' THEN 'Non' 
            ELSE 'Oui' 
        END
        WHERE [vehicle_uid] = ?";

        // Préparer les paramètres de la requête
        $params = array($vehicle_uid);

        // Exécuter la requête
        $stmt = sqlsrv_query($conn, $sql, $params);

        // Vérifier si la requête est exécutée correctement
        if ($stmt === false) {
            echo json_encode(['error' => 'Erreur lors de l\'exécution de la mise à jour.']);
            exit();
        }

        // Vérifier le nombre de lignes affectées
        $rowsAffected = sqlsrv_rows_affected($stmt);
        if ($rowsAffected === false) {
            echo json_encode(['error' => 'Impossible de déterminer le nombre de lignes affectées.']);
        } elseif ($rowsAffected == 0) {
            echo json_encode(['message' => 'Aucune ligne affectée.']);
        } else {
            echo json_encode(['message' => "$rowsAffected ligne(s) mise(s) à jour avec succès."]);
        }

        // Libérer la mémoire et fermer la connexion
        sqlsrv_free_stmt($stmt);
        sqlsrv_close($conn);
    } else {
        echo json_encode(['error' => 'Données manquantes.']);
    }
}
?>

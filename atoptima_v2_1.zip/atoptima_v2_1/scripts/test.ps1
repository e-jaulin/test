param (
    [string]$packageName,
    [string]$optDepot
)

# Chemin de base vers le package SSIS
$basePackagePath = 'C:\00 - Projets\1 - Logistique\Atoptima\Packages SSIS\Atoptima_SSIS\'

# Initialiser le chemin vers le package SSIS
$ssisPackagePath = $ssisPackagePath = $basePackagePath + 'LOAD_CSV_555Files_01.dtsx'

# Commande pour exécuter le package SSIS avec dtexec
$command = "dtexec /f `"$ssisPackagePath`""

# Exécuter la commande et capturer la sortie
$output = Invoke-Expression $command

# Afficher la sortie
Write-Output $output
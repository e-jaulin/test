<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    header('Content-Type: application/json; charset=utf-8');

    if (isset($_POST['cmdSelect'])) {        
        require_once "connexion.php";

        $cmdSelect = $_POST['cmdSelect'];

        // Transformer $cmdSelect en tableau en séparant par des virgules
        $idCmdeArray = explode(',', $cmdSelect);

        // Construire la chaîne de placeholders (autant de "?" qu'il y a d'ID)
        $placeholders = implode(',', array_fill(0, count($idCmdeArray), '?'));

        // Requête SQL de mise à jour
        $sql = "
        UPDATE t
        SET [IS_SELECTED] = CASE 
            WHEN [IS_SELECTED] = 1 THEN 0 
            ELSE 1 
        END
        FROM [BDT_ODS].[logistics].[".$TABLE_COMMANDE."] t
        WHERE [ID_DATELIV_CLIENT] IN ($placeholders)";

        // Préparer les paramètres de la requête
        $params = $idCmdeArray;

        // Exécuter la requête
        $stmt = sqlsrv_query($conn, $sql, $params);

        // Vérifier si la requête est exécutée correctement
        if ($stmt === false) {
            echo json_encode(['error' => 'Erreur lors de l\'exécution de la mise à jour.']);
            exit();
        }

        // Vérifier le nombre de lignes affectées
        $rowsAffected = sqlsrv_rows_affected($stmt);
        if ($rowsAffected === false) {
            echo json_encode(['error' => 'Impossible de déterminer le nombre de lignes affectées.']);
        } elseif ($rowsAffected == 0) {
            echo json_encode(['message' => 'Aucune ligne affectée.']);
        } else {
            echo json_encode(['message' => "$rowsAffected ligne(s) mise(s) à jour avec succès."]);
        }

        // Libérer la mémoire et fermer la connexion
        sqlsrv_free_stmt($stmt);
        sqlsrv_close($conn);
    } else {
        echo json_encode(['error' => 'Données manquantes.']);
    }
}
?>

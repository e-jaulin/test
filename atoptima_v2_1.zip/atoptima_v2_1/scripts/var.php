<?php
$VUE_COMMANDE="v_Affichage_Commandes_v2_1";
$TABLE_COMMANDE="Stg_CommandesBASISAtoptima_v2_1_01";
$TABLE_CLIENT="DimClient_v2_1_01";
$TABLE_VEHICULE="DimVehiculesLogistique_v2_1";
$TABLE_PARAMETERS="Input_Parameters_v2_Esteban";
?>
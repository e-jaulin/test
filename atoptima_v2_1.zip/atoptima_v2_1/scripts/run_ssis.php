<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    header('Content-Type: application/json; charset=utf-8');

    if(isset($_POST['packageName']) && isset($_POST['optDepot'])) {
        // Nom du package
        $packageName = $_POST['packageName'];
        $packageName = escapeshellarg($packageName);
        $optDepot = $_POST['optDepot'];
        $version = $_POST['version'];

        // Chemin vers votre script PowerShell
        $powershellScriptPath = 'C:\laragon\www\ze_atoptima\scripts\run_ssis.ps1';

        // Commande pour exécuter le script PowerShell
        $command = "powershell -NoLogo -NonInteractive -ExecutionPolicy Bypass -File \"$powershellScriptPath\" -packageName $packageName -optDepot $optDepot -version $version";

        // Exécuter la commande et capturer la sortie
        $output = shell_exec($command);

        file_put_contents('powershell_log.txt', $output);

        if ($output === null) {
            echo "Erreur lors de l'exécution de la commande.";
        } else {
            $output = mb_convert_encoding($output, 'UTF-8', mb_detect_encoding($output, 'UTF-8, ISO-8859-1', true));
            $output = html_entity_decode($output, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }
        
        $output = nl2br(htmlspecialchars($output));
        
        // Initialisation des variables pour stocker les différentes informations extraites
        $errors = array();
        $warnings = array();
        $infos = array();   
        
        $err = false;

        // Séparer les lignes de la sortie
        $lines = explode("\n", $output);
        foreach ($lines as $line) {
            
            if(stripos($line, "Fin de l'erreur") !== false) {
                $err = false;
            } elseif (stripos($line, 'Erreur') !== false || $err == true) {
                $errors[] = $line;
                $err = true;
            } elseif (stripos($line, 'Avertissement') !== false) {
                $warnings[] = $line;
            } else {
                $infos[] = $line;
            }
        }
        
        $output_data = array(
            "errors" => $errors,
            "warnings" => $warnings,
            "infos" => $infos
        );

        echo json_encode(array("output" => $output_data));
    }
}
?>

<?php
require_once "var.php";

// Informations de connexion
$serverName = "SRVNDSQL23";
$connectionOptions = array(
    "Database" => "BDT_ODS",
    "Uid" => "atoptima_test",   // Remplacez par votre nom d'utilisateur
    "PWD" => "atoptitest"        // Remplacez par votre mot de passe
);

// Connexion au serveur SQL Server
$conn = sqlsrv_connect( $serverName, $connectionOptions );

// Vérifier la connexion
if( !$conn ) {
    die( print_r(sqlsrv_errors(), true));
}
?>

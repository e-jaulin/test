<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    header('Content-Type: application/json; charset=utf-8');

    require_once "connexion.php";

    // Vérifier si CODE_CLIENT_BASIS est présent (clé primaire requise)
    if (!isset($_POST['CODE_CLIENT_BASIS']) || empty($_POST['CODE_CLIENT_BASIS'])) {
        echo json_encode(['error' => 'Le code client est obligatoire pour la mise à jour.']);
        exit();
    }

    $code_client = $_POST['CODE_CLIENT_BASIS']; // ID client obligatoire
    unset($_POST['CODE_CLIENT_BASIS']); // On le retire pour ne pas le modifier

    // Construire dynamiquement la requête SQL
    $set_clause = [];
    $params = [];

    foreach ($_POST as $column => $value) {
        if (!empty($value)) { // Ne met à jour que les champs non vides
            $set_clause[] = "[$column] = ?";
            $params[] = $value;
        }
    }

    // Vérifier s'il y a bien des champs à mettre à jour
    if (empty($set_clause)) {
        echo json_encode(['message' => 'Aucune donnée à mettre à jour.']);
        exit();
    }

    // Ajouter le filtre WHERE pour le bon client
    $params[] = $code_client;
    $sql = "UPDATE [logistics].[".$TABLE_CLIENT."] SET " . implode(", ", $set_clause) . " WHERE [CODE_CLIENT_BASIS] = ?";

    // Exécuter la requête
    $stmt = sqlsrv_query($conn, $sql, $params);

    if ($stmt === false) {
        echo json_encode(['error' => 'Erreur SQL : ' . print_r(sqlsrv_errors(), true)]);
        exit();
    }

    // Vérifier le nombre de lignes affectées
    $rowsAffected = sqlsrv_rows_affected($stmt);
    if ($rowsAffected === false) {
        echo json_encode(['error' => 'Impossible de déterminer le nombre de lignes affectées.']);
    } elseif ($rowsAffected == 0) {
        echo json_encode(['message' => 'Aucune ligne mise à jour.']);
    } else {
        echo json_encode(['message' => "$rowsAffected ligne(s) mise(s) à jour avec succès."]);
    }

    // Libérer la mémoire et fermer la connexion
    sqlsrv_free_stmt($stmt);
    sqlsrv_close($conn);
}
?>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    header('Content-Type: application/json; charset=utf-8');

    if (isset($_POST['optDepot'])) {
        $optDepot = $_POST['optDepot'];

        require_once "connexion.php";

        // Vérifier si la connexion est valide
        if (!$conn) {
            echo json_encode(['error' => 'Connexion à la base de données échouée.']);
            exit();
        }

        // Requête SQL
        $sql = "
        SELECT TOP (1000) 
        [DATE_LIV_DT]
      ,[CODE_CLIENT_BASIS] as 'Code client'
      ,[LIBELLE_CLIENT] as 'Libellé'
      ,[TypeActivite] as 'Type Activité'
      ,[NbreColis] as 'Nb Colis'
      ,[IS_SELECTED]
      ,[TriTypeAct] as 'Tri Type Act'
      ,[HEUREDEBUT_CLIENT] as 'Heure début'
      ,[ID_DATELIV_CLIENT] as 'ID'
        FROM [BDT_ODS].[logistics].[".$VUE_COMMANDE."]
        WHERE [DEPOT] = ?;";

        // Exécution de la requête
        $params = array($optDepot);
        $stmt = sqlsrv_query($conn, $sql, $params);

        // Vérification de l'exécution
        if ($stmt === false) {
            echo json_encode(['error' => 'Erreur lors de l\'exécution de la requête SQL.']);
            exit();
        }

        $data = array();

        // Récupération des résultats
        while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            // Convertir la date si elle est un objet DateTime
            if ($row['DATE_LIV_DT'] instanceof DateTime) {
                $row['DATE_LIV_DT'] = $row['DATE_LIV_DT']->format('Y-m-d H:i:s');
            }
            $data[] = $row;
        }

        // Retourner les données en JSON
        echo json_encode($data);

        // Libérer la mémoire et fermer la connexion
        sqlsrv_free_stmt($stmt);
        sqlsrv_close($conn);
    } else {
        echo json_encode(['error' => 'Paramètre manquant.']);
    }
} else {
    echo json_encode(['error' => 'Méthode non autorisée.']);
}
?>
<?php
header("Access-Control-Allow-Origin: http://localhost:5174");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key");
header("Access-Control-Allow-Credentials: true");

// Gérer les requêtes OPTIONS (prévol)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// Définir le type de contenu pour JSON
header('Content-Type: application/json');
define('API_KEY', 'f20d3c062b22840f08124f67ba25d68a');

// ===== CONTROLE =====
// Récupérer tous les en-têtes HTTP
$headers = getallheaders();

// Vérifiez si l'en-tête API_KEY est présent
if (!isset($_SERVER['HTTP_X_API_KEY']) || $_SERVER['HTTP_X_API_KEY'] !== API_KEY) {
    http_response_code(401); // Non autorisé
    echo json_encode(["error" => "Clé API invalide."]);
    exit;
}

/*$allowed_ips = ['192.168.1.100', '203.0.113.5'];

if (!in_array($_SERVER['REMOTE_ADDR'], $allowed_ips)) {
    http_response_code(403); // Accès interdit
    echo json_encode(["error" => "Votre IP n'est pas autorisée à accéder à cette API."]);
    exit;
}*/

// Vérifier que la méthode utilisée est POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); // Méthode non autorisée
    echo json_encode(["error" => "Seules les requêtes POST sont autorisées."]);
    exit;
}

// Lire et décoder le corps de la requête JSON
$data = json_decode(file_get_contents('php://input'), true);

// Vérifier si des paramètres sont fournis
if (empty($data)) {
    http_response_code(400); // Mauvaise requête
    echo json_encode(["error" => "Aucun paramètre fourni."]);
    exit;
}

// Validation stricte
if (!isset($data['packageName']) || !preg_match('/^[a-zA-Z0-9_-]+$/', $data['packageName'])) {
    http_response_code(400);
    echo json_encode(["error" => "Le paramètre 'packageName' est invalide."]);
    exit;
}

if (!isset($data['optDepot']) || !preg_match('/^\d{2}$/', $data['optDepot'])) {
    http_response_code(400);
    echo json_encode(["error" => "Le paramètre 'optDepot' est invalide."]);
    exit;
}

$log_file = __DIR__ . '/access.log';
$log_data = sprintf(
    "[%s] IP: %s | Params: %s\n",
    date('Y-m-d H:i:s'),
    $_SERVER['REMOTE_ADDR'],
    json_encode($data)
);
file_put_contents($log_file, $log_data, FILE_APPEND);




// Nom du package
$packageName = $data['packageName'];
$packageName = escapeshellarg($packageName);
$optDepot = $data['optDepot'];

// Chemin vers votre script PowerShell
$powershellScriptPath = 'C:\laragon\www\atoptima2\scripts\run_ssis.ps1';

// Commande pour exécuter le script PowerShell
$command = "powershell -NoLogo -NonInteractive -ExecutionPolicy Bypass -File \"$powershellScriptPath\" -packageName $packageName -optDepot $optDepot";

// Exécuter la commande et capturer la sortie
$output = shell_exec($command);

file_put_contents('powershell_log.txt', $output);

if ($output === null) {
    echo "Erreur lors de l'exécution de la commande.";
} else {
    $output = mb_convert_encoding($output, 'UTF-8', mb_detect_encoding($output, 'UTF-8, ISO-8859-1', true));
    $output = html_entity_decode($output, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

$output = nl2br(htmlspecialchars($output));

// Initialisation des variables pour stocker les différentes informations extraites
$errors = array();
$warnings = array();
$infos = array();   

$err = false;

// Séparer les lignes de la sortie
$lines = explode("\n", $output);
foreach ($lines as $line) {
    
    if(stripos($line, "Fin de l'erreur") !== false) {
        $err = false;
    } elseif (stripos($line, 'Erreur') !== false || $err == true) {
        $errors[] = $line;
        $err = true;
    } elseif (stripos($line, 'Avertissement') !== false) {
        $warnings[] = $line;
    } else {
        $infos[] = $line;
    }
}

$output_data = array(
    "errors" => $errors,
    "warnings" => $warnings,
    "infos" => $infos
);

echo json_encode(array("output" => $output_data));
?>

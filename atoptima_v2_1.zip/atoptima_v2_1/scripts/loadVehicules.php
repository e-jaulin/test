<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    header('Content-Type: application/json; charset=utf-8');

    if (isset($_POST['optDepot'])) {
        $optDepot = $_POST['optDepot'];

        require_once "connexion.php";

        // Vérifier si la connexion est valide
        if (!$conn) {
            echo json_encode(['error' => 'Connexion à la base de données échouée.']);
            exit();
        }

        // Requête SQL        
        $sql = "
        SELECT TOP (1000) [vehicle_uid]
      ,[MARQUE]
      ,[TYPE]
      ,[BOX]
      ,[COUT_FIXE]
      ,[DISPO]
        FROM [BDT_ODS].[logistics].[".$TABLE_VEHICULE."]
        WHERE [DEPOT] = ?;";

        // Exécution de la requête
        $params = array($optDepot);
        $stmt = sqlsrv_query($conn, $sql, $params);

        // Vérification de l'exécution
        if ($stmt === false) {
            echo json_encode(['error' => 'Erreur lors de l\'exécution de la requête SQL.']);
            exit();
        }

        $data = array();

        // Récupération des résultats
        while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            $data[] = $row;
        }

        // Retourner les données en JSON
        echo json_encode($data);

        // Libérer la mémoire et fermer la connexion
        sqlsrv_free_stmt($stmt);
        sqlsrv_close($conn);
    } else {
        echo json_encode(['error' => 'Paramètre manquant.']);
    }
} else {
    echo json_encode(['error' => 'Méthode non autorisée.']);
}
?>
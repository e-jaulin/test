document.addEventListener('DOMContentLoaded', function() {	
	const depots = document.getElementById('depots');
	const commandes = document.getElementById('commandes');
	const btnLoadCommandes = document.getElementById('btnLoadCommandes');
	const btnDepot = document.querySelectorAll(".btnDepot");
	const btnNavs = document.querySelectorAll(".btn-nav");
	const btnCloseFiche = document.getElementById("btn-close-fiche");
	const btnForm = document.getElementById("btn-form");
	const tableBdtOds = document.getElementById("table-bdtods");
	const tableClients = document.getElementById("table-clients");
	const cardsVehicule = document.getElementById("bloc-cards-vehicule");
	const elementNbCamions = document.getElementById("nbCamionDispo");
	const inputNbCamionsSelected = document.getElementById("nbCamionsSelected");	
	const elementNbColis = document.getElementById("nbColis");
	const alertLancement = document.getElementById("alert-lancement");
	const elementStatus = document.getElementById('status');
	const versionSelect = document.getElementById("versionSelect");
	const loader = document.getElementById("loader");	
	const runButtons = document.querySelectorAll(".runButton");
	const nav = document.getElementById("navbar");	
	const nomDepot = document.getElementById("nom-depot");	
	const elementToast = document.getElementById("toast");
	
	let dynamicForm = document.getElementById("dynamicForm");
	let form = document.getElementById("formulaire-client");
	
	const listeClients = document.getElementById("liste-clients");
	const ficheClient = document.getElementById("fiche-client");

	var nbCamionsSelected = 0;
	var depot = 0;
	var selectedCmdes = [];
	var selectAll = false;
	var sommeColis = 0;
	var nbCamionDispo = 0;
	var packageName = "";
	var version = "v2_1";
	var clientSelected = 0;

	// EVENTS =============================
	btnNavs.forEach(function(btn) {
		btn.addEventListener('click', function() {

			document.querySelectorAll(".btn-selected").forEach(function(e){e.classList.remove("btn-selected")});
			btn.classList.add("btn-selected");


			ecran = this.dataset.screen;
			const screens = document.querySelectorAll(".screen");

			screens.forEach(function(screen){
				screen.classList.add("d-none");

				if(screen.dataset.screen == ecran) {
					screen.classList.remove("d-none");
				}
			});

			if(ecran == "accueil") {
				nav.classList.add("d-none");
				nomDepot.classList.add("d-none");				
				version = "v2_1";
				depot = 0;
				resetData();
			}
		});
	});
	
	btnDepot.forEach(function(btn) {
		btn.addEventListener('click', function() {
			document.querySelectorAll(".btn-selected").forEach(function(e){e.classList.remove("btn-selected")});
			document.getElementById("btn-etape1").classList.add("btn-selected");

			depot = this.dataset.depot;
			depotName = this.dataset.depotName;
			nav.classList.remove("d-none");
			nomDepot.innerHTML = "Dépot - " + depotName;
			nomDepot.classList.remove("d-none");
			depots.classList.add('d-none');
			commandes.classList.remove('d-none');
		});
	});

	btnCloseFiche.addEventListener('click', function() {
		closeFiche();
	});

	btnLoadCommandes.addEventListener('click', function() {
		resetData();
		packageName = this.dataset.packageName;

		if(depot!="0") {
			loader.classList.remove('d-none');
			tableBdtOds.classList.add("d-none");
			tableClients.classList.add("d-none");
			runScriptPhp(packageName, depot, versionSelect.value);
		}
	});

	runButtons.forEach(function(btn) {
		btn.addEventListener('click', function(event) {
			event.preventDefault();
			packageName = this.dataset.packageName;
			version = versionSelect.value;
			alertLancement.classList.add("d-none");

			if(depot!="0") {
				if(packageName == "LANCER") {
					
					//on controle si des commandes et camions sont sélectionnées
					if(selectedCmdes.length != 0 && nbCamionsSelected > 0) {
						updateFlag(selectedCmdes);
						updateCamion(nbCamionsSelected, depot);
						//runScriptPhp(packageName, depot, versionSelect.value);
					} else {
						alertLancement.classList.remove("d-none");
					}
				} else {
					elementStatus.classList.remove("bg-green");
					elementStatus.classList.remove("bg-red");
					loader.classList.remove('d-none');

					runScriptPhp(packageName, depot, version);
				}				
			}			
		});
	});

	versionSelect.addEventListener('change', function() {
		if(this.value == 'v1' || this.value ==  'v2') {
			location.href = "http://srvndsql23/atoptima2";
		}
	});

	inputNbCamionsSelected.addEventListener("input", function() {
		nbCamionsSelected = this.value;
	});
	
	btnForm.addEventListener("click", function (e) {		
		updateClient(clientSelected);
	});

	// FUNCTIONS =============================
	function resetData() {
		nbCamionsSelected = 0;
		selectedCmdes = [];
		selectAll = false;
		sommeColis = 0;
		nbCamionDispo = 0;
		packageName = "";
		elementNbColis.innerHTML = 0;
		elementNbCamions.innerHTML = 0;
		cardsVehicule.innerHTML = '';
		tableBdtOds.classList.add("d-none");	
		tableClients.classList.add("d-none");	
		cardsVehicule.classList.add("d-none");		
		elementStatus.classList.add("d-none");		
		alertLancement.classList.add("d-none");		
	}

	function runScriptPhp(packageName, optDepot, version) {
		var xhr = new XMLHttpRequest();
		xhr.open('POST', 'scripts/run_ssis.php');
		xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

		xhr.onload = function() {
			if (xhr.status === 200) {
				try {
					var response = JSON.parse(xhr.responseText);
					var errors = response.output.errors;
					var infos = response.output.infos;

					if(packageName == "LOAD_Commandes") {
						loadCommande(optDepot);
						loadClients(optDepot);
						loadVehicules(optDepot);
					} else {
						loader.classList.add('d-none');
						var response = JSON.parse(xhr.responseText);
						var errors = response.output.errors;
						var infos = response.output.infos;

						if (errors != "") {
							elementStatus.classList.add("bg-red");
							elementStatus.innerHTML = errors;
						} else {
							elementStatus.classList.add("bg-green");
							elementStatus.innerHTML = infos;
						}
						
						elementStatus.classList.remove("d-none");
					}
				} catch (e) {
					afficheToast(false, 'Erreur lors de l\'exécution du package SSIS (analyse JSON).');
				}
			} else {
				afficheToast(false, 'Erreur lors de l\'exécution du package SSIS (réponse HTTP).');
			}
		};

		xhr.onerror = function() {
			afficheToast(false, 'Erreur lors de l\'exécution du package SSIS (connexion).');
		};

		xhr.send("packageName="+packageName+"&optDepot="+optDepot+"&version="+version);
	}

	function loadCommande(optDepot) {
		var xhr = new XMLHttpRequest();
		xhr.open('POST', 'scripts/loadCommande.php');
		xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

		xhr.onload = function() {
			if (xhr.status === 200) {
				try {							
					loader.classList.add('d-none');						
					tableBdtOds.classList.remove("d-none");	
					var response = JSON.parse(xhr.responseText);
										
					const tbody = document.querySelector('#table-bdtods tbody');
					tbody.innerHTML = "";
					const thead = document.querySelector('#table-bdtods thead');
					thead.innerHTML = "";

					i=0;
					th_ok = false;
					
					response.forEach(element => {
						if(!th_ok) {							
							const rowHead = document.createElement('tr');
							rowHead.classList.add("lines");
							const cell = document.createElement('th');
							const checkbox = document.createElement('input');
							checkbox.type = "checkbox";
							checkbox.classList.add("form-check-input");
							checkbox.id = "check-tout";

							checkbox.addEventListener("click", function() {
								selectAllCheckboxes();
							});

							cell.appendChild(checkbox);
							cell.classList.add("thead-dark");
							cell.classList.add("th-check");
							rowHead.appendChild(cell);

							for (const key in element) {
								if (element.hasOwnProperty(key)) {					
									const cell = document.createElement('th');
									cell.classList.add("thead-dark");
									cell.innerHTML = `${key}`;
									if(key == "Sélectionné") {
										cell.classList.add("d-none");
									}
									rowHead.appendChild(cell);								
								}
							}

							thead.appendChild(rowHead);

							th_ok = true;
						}
						
						const newRow = document.createElement('tr');
						newRow.classList.add("lines");

						const cell = document.createElement('td');
						const checkbox = document.createElement('input');
						checkbox.type = "checkbox";
						checkbox.classList.add("form-check-input");
						cell.appendChild(checkbox);
						cell.classList.add("text-center");
						newRow.appendChild(cell);

						for (const key in element) {
							if (element.hasOwnProperty(key)) {					
								const cell = document.createElement('td');
								cell.innerHTML = `${element[key]}`;
								if(key == "Sélectionné") {
									cell.classList.add("d-none");
								}

								if(key == "ID") {																			
									newRow.dataset.idCmde = `${element[key]}`;
								}

								if(key == "Nb Colis") {																			
									newRow.dataset.nbColis = `${element[key]}`;
								}

								if(key == "Sélectionné" && `${element[key]}` == '1') {
									newRow.classList.add("cmdSelected");
								}

								newRow.appendChild(cell);
							}
						}

						newRow.addEventListener("click", function(event) {
							if (event.target !== checkbox) {
								// Toggle la case à cocher
								checkbox.checked = !checkbox.checked;
							}
							
							if(!checkbox.checked) {
								selectAll = false;
								const checkTout = document.getElementById("check-tout");
								checkTout.checked = false;
							}

							// Toggle (ajoute ou retire) la classe "selected" à la ligne cliquée
							this.classList.toggle("selected");

							// Récupère l'idCmde de la ligne cliquée
							const idCmde = this.dataset.idCmde;

							// Vérifie si l'idCmde est déjà dans le tableau
							const index = selectedCmdes.indexOf(idCmde);							
							const nbColis = parseInt(newRow.dataset.nbColis);

							if (index > -1) {
								// Si l'idCmde est déjà dans le tableau, on le retire
								selectedCmdes.splice(index, 1);
								sommeColis -= nbColis
							} else {
								// Sinon, on l'ajoute
								selectedCmdes.push(idCmde);
								sommeColis += nbColis
							}								
							
							elementNbColis.innerHTML = sommeColis;							
						});
						
						tbody.appendChild(newRow);						
						
						i++;	
					});
										
					document.querySelectorAll("#table-bdtods th:not(.th-check)").forEach((headerCell, index) => {
						let sortIcon = document.createElement("span");
						sortIcon.style.marginLeft = "8px";
						headerCell.appendChild(sortIcon);
				
						headerCell.addEventListener("click", () => {
							let table = headerCell.closest("table");
							let tbody = table.querySelector("tbody");
							let rows = Array.from(tbody.querySelectorAll("tr"));
				
							let ascending = headerCell.dataset.order !== "asc";
							headerCell.dataset.order = ascending ? "asc" : "desc";
				
							// Réinitialiser toutes les icônes
							document.querySelectorAll("#table-bdtods th span").forEach(span => span.textContent = "");
				
							// Ajouter l'icône appropriée
							sortIcon.textContent = ascending ? " ⬆️" : " ⬇️";
				
							rows.sort((rowA, rowB) => {
								let cellA = rowA.children[index+1].textContent.trim();
								let cellB = rowB.children[index+1].textContent.trim();
								let compare = isNaN(cellA) || isNaN(cellB)
									? cellA.localeCompare(cellB)
									: Number(cellA) - Number(cellB);
								return ascending ? compare : -compare;
							});
				
							tbody.append(...rows);
						});
					});

					let searchInput = document.getElementById("searchInput");
					let clearBtn = document.getElementById("clearBtn");

					searchInput.addEventListener("input", function () {
						let filter = this.value.toLowerCase();
						let rows = document.querySelectorAll("#table-bdtods tbody tr");

						rows.forEach(row => {
							let text = row.textContent.toLowerCase();
							row.style.display = text.includes(filter) ? "" : "none";
						});

						// Afficher ou masquer la croix selon le texte
						clearBtn.style.display = this.value ? "block" : "none";
					});

					// Bouton pour effacer le texte et réinitialiser l'affichage
					clearBtn.addEventListener("click", function () {
						searchInput.value = "";
						clearBtn.style.display = "none";

						// Afficher toutes les lignes du tableau
						document.querySelectorAll("#table-bdtods tbody tr").forEach(row => {
							row.style.display = "";
						});

						searchInput.focus();
					});				

				} catch (e) {
					afficheToast(false, 'Erreur : ' + e);
				}
			} else {
				afficheToast(false, 'Erreur réponse HTTP');
			}
		};

		xhr.onerror = function() {
			afficheToast(false, 'Erreur connexion');
		};

		xhr.send("optDepot="+optDepot);
	}

	function loadInfoClient(optDepot, codeClient) {
		clientSelected = codeClient;
		var xhr = new XMLHttpRequest();
		xhr.open('POST', 'scripts/loadClients.php');
		xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

		xhr.onload = function() {
			if (xhr.status === 200) {
				try {	
					var response = JSON.parse(xhr.responseText)[0];

					form.innerHTML = "";

					for (let key in response) {
						let value = response[key] !== null ? response[key] : "";

						let label = document.createElement("label");
						label.textContent = key.replace(/_/g, " ");

						let input = document.createElement("input");
						input.type = "text"; //typeof value === "number" ? "number" : 
						input.name = key;
						input.value = value;

						/*if(key == "CODE_CLIENT_SCH" || key == "CODE_CLIENT_BASIS" || key == "LIBELLE_CLIENT") {
							input.disabled = true;
						}*/

						let rowInput = document.createElement("div");
						rowInput.classList.add("row");
						let colLabel = document.createElement("div");
						let colInput = document.createElement("div");
						colLabel.classList.add("col-6");
						colInput.classList.add("col-6");

						colLabel.append(label);
						colInput.append(input);

						rowInput.append(colLabel);
						rowInput.append(colInput);

						form.appendChild(rowInput);
					}
				} catch(e) {
					afficheToast(false, 'Erreur : ' + e);
				}
			} else {
				afficheToast(false, 'Erreur réponse HTTP');
			}
		}

		xhr.onerror = function() {
			afficheToast(false, 'Erreur connexion');
		};

		xhr.send("optDepot="+optDepot+"&codeClient="+codeClient);
	}

	function loadClients(optDepot) {
		var xhr = new XMLHttpRequest();
		xhr.open('POST', 'scripts/loadClients.php');
		xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

		xhr.onload = function() {
			if (xhr.status === 200) {
				try {											
					tableClients.classList.remove("d-none");	
					var response = JSON.parse(xhr.responseText);
										
					const tbody = document.querySelector('#table-clients tbody');
					tbody.innerHTML = "";
					const thead = document.querySelector('#table-clients thead');
					thead.innerHTML = "";

					i=0;
					th_ok = false;
					
					response.forEach(element => {			
						if(!th_ok) {							
							const rowHead = document.createElement('tr');
							rowHead.classList.add("lines");

							for (const key in element) {
								if (element.hasOwnProperty(key)) {					
									const cell = document.createElement('th');
									cell.classList.add("thead-dark");
									cell.innerHTML = `${key}`;
									
									rowHead.appendChild(cell);								
								}
							}

							thead.appendChild(rowHead);

							th_ok = true;
						}
						
						const newRow = document.createElement('tr');
						newRow.classList.add("lines");

						for (const key in element) {
							if (element.hasOwnProperty(key)) {					
								const cell = document.createElement('td');
								cell.innerHTML = `${element[key]}`;
								if(key == "Sélectionné") {
									cell.classList.add("d-none");
								}

								if(key == "CODE_CLIENT_BASIS") {																			
									newRow.dataset.codeClient = `${element[key]}`;
								}

								if(key == "Nb Colis") {																			
									newRow.dataset.nbColis = `${element[key]}`;
								}

								if(key == "Sélectionné" && `${element[key]}` == '1') {
									newRow.classList.add("cmdSelected");
								}

								newRow.appendChild(cell);
							}
						}

						newRow.addEventListener("click", function(event) {
							/*if (event.target !== checkbox) {
								// Toggle la case à cocher
								checkbox.checked = !checkbox.checked;
							}
							
							if(!checkbox.checked) {
								selectAll = false;
								const checkTout = document.getElementById("check-tout");
								checkTout.checked = false;
							}*/

							// Toggle (ajoute ou retire) la classe "selected" à la ligne cliquée
							document.querySelectorAll(".selected").forEach(function(e) {e.classList.remove("selected")}); 
							
							this.classList.add("selected");

							listeClients.classList.remove("col-12");
							listeClients.classList.add("col-8");
							ficheClient.classList.remove("d-none");

							loadInfoClient(depot, this.dataset.codeClient);
						});
						
						tbody.appendChild(newRow);						
						
						i++;	
					});
					
					
						document.querySelectorAll("#table-clients th").forEach((headerCellClient, index) => {
							let sortIcon = document.createElement("span");
							sortIcon.style.marginLeft = "8px";
							headerCellClient.appendChild(sortIcon);
					
							headerCellClient.addEventListener("click", () => {
								let table = headerCellClient.closest("table");
								let tbody = table.querySelector("tbody");
								let rows = Array.from(tbody.querySelectorAll("tr"));
					
								let ascending = headerCellClient.dataset.order !== "asc";
								headerCellClient.dataset.order = ascending ? "asc" : "desc";
					
								// Réinitialiser toutes les icônes
								document.querySelectorAll("#table-clients th span").forEach(span => span.textContent = "");
					
								// Ajouter l'icône appropriée
								sortIcon.textContent = ascending ? " ⬆️" : " ⬇️";
					
								rows.sort((rowA, rowB) => {
									let cellA = rowA.children[index].textContent.trim();
									let cellB = rowB.children[index].textContent.trim();
									let compare = isNaN(cellA) || isNaN(cellB)
										? cellA.localeCompare(cellB)
										: Number(cellA) - Number(cellB);
									return ascending ? compare : -compare;
								});
					
								tbody.append(...rows);
							});
						});

						let searchInput = document.getElementById("searchInputClient");
						let clearBtn = document.getElementById("clearBtnClient");

						searchInput.addEventListener("input", function () {
							let filter = this.value.toLowerCase();
							let rows = document.querySelectorAll("#table-clients tbody tr");

							rows.forEach(row => {
								let text = row.textContent.toLowerCase();
								row.style.display = text.includes(filter) ? "" : "none";
							});

							// Afficher ou masquer la croix selon le texte
							clearBtn.style.display = this.value ? "block" : "none";
						});

						// Bouton pour effacer le texte et réinitialiser l'affichage
						clearBtn.addEventListener("click", function () {
							searchInput.value = "";
							clearBtn.style.display = "none";

							// Afficher toutes les lignes du tableau
							document.querySelectorAll("#table-clients tbody tr").forEach(row => {
								row.style.display = "";
							});

							searchInput.focus();
						});
					

				} catch (e) {
					afficheToast(false, 'Erreur : ' + e);
				}
			} else {
				afficheToast(false, 'Erreur réponse HTTP');
			}
		};

		xhr.onerror = function() {
			afficheToast(false, 'Erreur connexion');
		};

		xhr.send("optDepot="+optDepot);
	}

	function loadVehicules(optDepot) {		
		var dispoElement = '<div class="statut dispo">Dispo</div>';
		var indispoElement = '<div class="statut indispo">Indispo</div>';

		var xhr = new XMLHttpRequest();
		xhr.open('POST', 'scripts/loadVehicules.php');
		xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");		

		xhr.onload = function() {
			if (xhr.status === 200) {
				try {								
					var response = JSON.parse(xhr.responseText);
										
    				cardsVehicule.innerHTML = '';
					cardsVehicule.classList.remove("d-none");	

					i=0;

					response.forEach(element => {
						
						const card = document.createElement('div');
						card.classList.add('vehicule-card');
						card.dataset.uid = element["vehicle_uid"];
						
						const grid = document.createElement('div');
						grid.classList.add('vehicule-grid');

						var elementDispo = element["DISPO"];

						if(elementDispo == "Oui") {
							elementDispo = dispoElement;
							card.dataset.dispo ="true";
							nbCamionDispo++;
						} else {
							elementDispo = indispoElement;
							card.dataset.dispo = "false";
						}

						elementNbCamions.innerHTML = nbCamionDispo;
						
						grid.innerHTML = 	'<div class="row">'+
												'<div class="col-2 text-center">'+
													'<img src="assets/camion.png" alt="img" height="30">'+
													'<div>'+elementDispo+'</div>'+
												'</div>'+
												'<div class="col-10">'+
													'<div class="row">'+
														'<div class="col-6"><b>'+element["vehicle_uid"]+'</b></div>'+
														'<div class="col-6">Box: '+element["BOX"]+'</div>'+
													'</div>'+
													'<div class="row">'+
														'<div class="col-6">'+element["MARQUE"]+'</div>'+
														'<div class="col-6">Cout fixe: '+element["COUT_FIXE"]+'</div>'+
													'</div>'+
												'</div>'+
											'</div>';						
						card.appendChild(grid);
        				cardsVehicule.appendChild(card);

						card.addEventListener('click', function() {
							updateDispo(this.dataset.uid, this.dataset.dispo);
						});
					});	
				} catch (e) {
					afficheToast(false, 'Erreur : ' + e);
				}
			} else {
				afficheToast(false, 'Erreur réponse HTTP');
			}
		};

		xhr.onerror = function() {
			afficheToast(false, 'Erreur connexion');
		};

		xhr.send("optDepot="+optDepot);
	}

	function updateFlag(selectedCmdes) {

		var xhr = new XMLHttpRequest();
		xhr.open('POST', 'scripts/updateFlag.php');
		xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

		xhr.onload = function() {
			if (xhr.status === 200) {
				try {
					var response = JSON.parse(xhr.responseText);
					if(response != "") {
						afficheToast(true, response["message"]);
					} else {
						afficheToast(false, response["message"]);
					}
				} catch (e) {
					afficheToast(false, 'Erreur lors de l\'exécution du package SSIS (analyse JSON).');
				}
			} else {
				afficheToast(false, 'Erreur lors de l\'exécution du package SSIS (réponse HTTP).');
			}
		};

		xhr.onerror = function() {
			afficheToast(false, 'Erreur lors de l\'exécution du package SSIS (connexion).');
		};

		xhr.send("cmdSelect="+selectedCmdes);

		selectedCmdes = [];
	}

	function updateCamion(nbCamionsSelected, depot) {
		var xhr = new XMLHttpRequest();
		xhr.open('POST', 'scripts/updateCamion.php');
		xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

		xhr.onload = function() {
			if (xhr.status === 200) {
				try {
					var response = JSON.parse(xhr.responseText);
				} catch (e) {
					afficheToast(false, 'Erreur lors de l\'exécution du package SSIS (analyse JSON).');
				}
			} else {
				afficheToast(false, 'Erreur lors de l\'exécution du package SSIS (réponse HTTP).');
			}
		};

		xhr.onerror = function() {
			afficheToast(false, 'Erreur lors de l\'exécution du package SSIS (connexion).');
		};

		xhr.send("nbCamionsSelected="+nbCamionsSelected+"&depot="+depot);
	}

	function updateDispo(vehicle_uid, dispo) {
		var xhr = new XMLHttpRequest();
		xhr.open('POST', 'scripts/updateDispo.php');
		xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

		xhr.onload = function() {
			if (xhr.status === 200) {
				try {
					const cardVehicules = document.querySelectorAll(".vehicule-card");
					cardVehicules.forEach(function(card) {
						if(card.dataset.uid == vehicle_uid) {
							const elementStatut = card.querySelector(".statut");
							
							if(dispo == "true") {
								elementStatut.innerHTML = "Indispo";
								elementStatut.classList.remove("dispo");
								elementStatut.classList.add("indispo");
								card.dataset.dispo = "false";
								nbCamionDispo--;
							} else if (dispo == "false") {
								elementStatut.innerHTML = "Dispo";
								elementStatut.classList.add("dispo");
								elementStatut.classList.remove("indispo");
								card.dataset.dispo = true;
								nbCamionDispo++;
							}
						}

						elementNbCamions.innerHTML = nbCamionDispo;
					});
				} catch (e) {
					afficheToast(false, 'Erreur lors de l\'exécution du package SSIS (analyse JSON).');
				}
			} else {
				afficheToast(false, 'Erreur lors de l\'exécution du package SSIS (réponse HTTP).');
			}
		};

		xhr.onerror = function() {
			afficheToast(false, 'Erreur lors de l\'exécution du package SSIS (connexion).');
		};

		xhr.send("vehicle_uid="+vehicle_uid);
	}

	function updateClient(codeClient) {		
		let xhr = new XMLHttpRequest();
		let formData = new FormData(dynamicForm); // Récupère les données du formulaire
	
		xhr.open('POST', 'scripts/updateClient.php', true);
		xhr.onreadystatechange = function () {
			if (xhr.readyState === 4) { // Requête terminée
				if (xhr.status === 200) {
					if(xhr.responseText != "") {
						let response = JSON.parse(xhr.responseText);

						if(response != "") {
							afficheToast(true, response["message"]);
						} else {
							afficheToast(false, response["message"]);
						}
					} else {
						afficheToast(false, "Erreur de modification, vérifiez les champs");
					}				
					
					closeFiche();
				} else {
					alert("Erreur de connexion au serveur.");
				}
			}
		};
	
		xhr.send(formData);
	}
	
	function selectAllCheckboxes() {
		const checkboxes = document.querySelectorAll('input[type="checkbox"]');
		selectedCmdes = [];
		sommeColis = 0;
	
		checkboxes.forEach(checkbox => {
			const row = checkbox.closest("tr");
			
			if (row) {
				if(!selectAll) {					
					checkbox.checked = true;
					row.classList.add("selected");
					const idCmde = row.dataset.idCmde;
					if (idCmde && !selectedCmdes.includes(idCmde)) {
						selectedCmdes.push(idCmde);
						sommeColis += parseInt(row.dataset.nbColis);
					}
				} else {
					checkbox.checked = false;
					row.classList.remove("selected");
				}				
			}
		});
		
		selectAll = !selectAll;		
		elementNbColis.innerHTML = sommeColis;
	}

	function afficheToast(success, message) {
		elementToast.classList.remove("bg-green", "bg-red", "slide-out");
		
		if (success) {
			elementToast.classList.add("bg-green");
		} else {
			elementToast.classList.add("bg-red");
		}
	
		elementToast.innerText = message;
		elementToast.style.opacity = "1"; // Rendre visible
		elementToast.classList.add("slide-in");
	
		// Supprime slide-in après l'animation d'entrée
		setTimeout(() => {
			elementToast.classList.remove("slide-in");
		}, 5000);
	
		// Disparition après 3 secondes
		setTimeout(() => {
			elementToast.classList.add("slide-out");
	
			// Réduction progressive de l'opacité avant de le cacher complètement
			setTimeout(() => {
				elementToast.style.opacity = "0";
			}, 100);
			
		}, 5000);
	}
	
	function closeFiche() {
		listeClients.classList.add("col-12");
		listeClients.classList.remove("col-8");
		ficheClient.classList.add("d-none");
		document.querySelectorAll(".selected").forEach(function(e) {e.classList.remove("selected")}); 
		codeClient = 0;
		form.innerHTML = "";
	}
});
import { afficheToast } from "./afficheToast";

export function runScriptPhp(packageName, optDepot, version) {
	var xhr = new XMLHttpRequest();
	xhr.open('POST', 'scripts/run_ssis.php');
	xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

	xhr.onload = function() {
		if (xhr.status === 200) {
			try {
				var response = JSON.parse(xhr.responseText);
				var errors = response.output.errors;
				var infos = response.output.infos;

				if(packageName == "LOAD_Commandes") {
					loadCommande(optDepot);
					loadClients(optDepot);
					loadVehicules(optDepot);
				} else {
					loader.classList.add('d-none');
					var response = JSON.parse(xhr.responseText);
					var errors = response.output.errors;
					var infos = response.output.infos;

					/*if (errors != "") {
						elementStatus.classList.add("bg-red");
						elementStatus.innerHTML = errors;
					} else {
						elementStatus.classList.add("bg-green");
						elementStatus.innerHTML = infos;
					}
					
					elementStatus.classList.remove("d-none");*/
				}
			} catch (e) {
				afficheToast(false, 'Erreur lors de l\'exécution du package SSIS (analyse JSON).');
			}
		} else {
			afficheToast(false, 'Erreur lors de l\'exécution du package SSIS (réponse HTTP).');
		}
	};

	xhr.onerror = function() {
		afficheToast(false, 'Erreur lors de l\'exécution du package SSIS (connexion).');
	};

	xhr.send("packageName="+packageName+"&optDepot="+optDepot+"&version="+version);
}
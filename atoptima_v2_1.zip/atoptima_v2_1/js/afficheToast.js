export function afficheToast(success, message) {
	const elementToast = document.getElementById("toast");
	elementToast.classList.remove("bg-green", "bg-red", "slide-out");
	
	if (success) {
		elementToast.classList.add("bg-green");
	} else {
		elementToast.classList.add("bg-red");
	}

	elementToast.innerText = message;
	elementToast.style.opacity = "1"; // Rendre visible
	elementToast.classList.add("slide-in");

	// Supprime slide-in après l'animation d'entrée
	setTimeout(() => {
		elementToast.classList.remove("slide-in");
	}, 5000);

	// Disparition après 3 secondes
	setTimeout(() => {
		elementToast.classList.add("slide-out");

		// Réduction progressive de l'opacité avant de le cacher complètement
		setTimeout(() => {
			elementToast.style.opacity = "0";
		}, 100);
		
	}, 5000);
}
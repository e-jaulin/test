<script type="text/javascript" src="js/bootstrap.js"></script>
<script type="text/javascript" src="js/feather.js"></script>
<script type="text/javascript" src="js/main.js"></script>
<script>
	feather.replace();
</script>
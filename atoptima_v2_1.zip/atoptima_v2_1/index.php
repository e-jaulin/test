<!DOCTYPE html>
<html lang="fr">
	<head>
		<?php include 'head.php'; ?>
	</head>

	<body>
		<?php include 'header.php'; ?>

		<div class="position-absolute top-50 start-50 translate-middle p-3">
			<div id="loader" class="loader d-none"></div>
		</div>

		<div id="depots" class="col-12 col-sm-4 mx-auto my-4 bloc-style screen" data-screen="accueil">			
			<div class="w-50 mx-auto">
				<h2 class="text-center">Sélectionnez le dépôt</h2>
				<br>
				<div class="d-grid gap-2 col-11 mx-auto">
					<a href="#" class="btnDepot btn-style" data-depot="01" data-depot-name="Arue">Arue</a>
					<a href="#" class="btnDepot btn-style" data-depot="02" data-depot-name="Punaruu">Punaruu</a>
					<a href="#" class="btnDepot btn-style" data-depot="11" data-depot-name="Moorea">Moorea</a>
					<a href="#" class="btnDepot btn-style" data-depot="12" data-depot-name="Raiatea">Raiatea</a>
					<a href="#" class="btnDepot btn-style" data-depot="20" data-depot-name="Bora-Bora">Bora-Bora</a>
				</div>
			</div>
		</div>

		<div id="commandes" class="col-12 col-sm-11 mx-auto my-4 d-none screen" data-screen="etape1">
			<div class="row">
				<div id="gauche" class="col-12 col-sm-7">
					<div class="bloc-style">
						<h2 class="text-center">Commandes</h2>
						
						<div class="row">
							<div class="col-5">
								<button id="btnLoadCommandes" class="btn-style" data-package-name="LOAD_Commandes">Charger les commandes</button>		
							</div>
							<div id="bloc-somme-colis" class="col-7 text-end pe-4">
								<div class="search-container">
									<input type="text" id="searchInput" placeholder="Rechercher..." />
									<span class="clear-btn" id="clearBtn"><i data-feather="x"></i></span>
								</div>
								<br>
								Nombre de colis : <span id="nbColis">0</span>
							</div>
						</div>

						<div id="liste-commandes" class="mt-4">
							<table id="table-bdtods" class="d-none">
								<thead class="thead-dark sticky-top">
									<tr></tr>
								</thead>
								<tbody>
									<tr></tr>
								</tbody>
							</table>
						</div>
					</div>					
				</div>

				<div id="droite" class="col-12 col-sm-5">
					<div id="camions" class="bloc-style">
						<h2 class="text-center">Camions</h2>
						
						<div class="row">
							<div class="col-5">
								<input type="number" name="nbCamions" id="nbCamionsSelected" placeholder="Nombre de camions">	
							</div>
							<div id="bloc-somme-camions" class="col-7 text-end pe-4">
								Camions disponibles : <span id="nbCamionDispo">0</span>
							</div>
						</div>
						
						<div id="liste-vehicules" class="mt-4">
							<div id="bloc-cards-vehicule"></div>
						</div>
					</div>
					<br>
					<div id="lancement" class="bloc-style">
						<h2 class="text-center">Lancement</h2>
						<div class="row my-2">
							<div class="col-10">Titre pour lancement</div>
							<div class="col-2">
								<button id="btnLancement" class="btn-style runButton" data-package-name="LANCER"><i data-feather="arrow-right"></i></button>
							</div>
						</div>
						<div id="alert-lancement" class="text-center text-danger d-none">
							Aucune commande ou aucun camion n'a été sélectionné
						</div>
					</div>
				</div>
			</div>
		</div>

		<div id="generation" class="col-12 col-sm-5 mx-auto my-4 d-none screen" data-screen="etape2">
			<div class="bloc-style">
				<h2 class="text-center">Titre étape 2</h2>
				<div class="row my-2">
					<div class="col-10">1 - Génération des fichiers CSV à déposer sur le site Atoptima</div>
					<div class="col-2">
						<button id="runPackageButton2" class="runButton btn-style" type="submit" title="bouton de lancement" data-package-name="LOAD_CSV_Files">
							<i data-feather="arrow-right"></i>
						</button>
					</div>
				</div>
				<div class="row my-2">			
					<div class="col-10">2 - Archivage des données depuis le fichier Output.json</div>
					<div class="col-2">
						<button id="runPackageButton3" class="runButton btn-style" type="submit" title="bouton de lancement" data-package-name="INPUT_JSON_Archive_File">
							<i data-feather="arrow-right"></i>
						</button>
					</div>
				</div>
				<div class="row my-2">		
					<div id="status" class="d-none">

					</div>
				</div>
			</div>
		</div>

		<div id="clients" class="col-12 col-sm-10 mx-auto my-4 bloc-style screen d-none" data-screen="client">			
			<div class="bloc-style">
				<h2 class="text-center">Clients</h2>
								
				<div class="search-container">
					<input type="text" id="searchInputClient" placeholder="Rechercher..." />
					<span class="clear-btn" id="clearBtnClient"><i data-feather="x"></i></span>
				</div>
			
				<div class="row">
					<div id="liste-clients" class="mt-4 col-12">
						<table id="table-clients" class="d-none">
							<thead class="thead-dark sticky-top">
								<tr></tr>
							</thead>
							<tbody>
								<tr></tr>
							</tbody>
						</table>
					</div>
					<div id="fiche-client" class="mt-4 col-4 bg-light d-none">						
						<form id="dynamicForm">	
							<div class="sticky-top bg-light row py-3">
								<div class="col-6 row">
									<div class="col-3">
										<button id="btn-close-fiche" class="btn-nostyle" type="button"><i data-feather="x"></i></button>
									</div>
									<div class="col-9">
										<h3>Informations</h3>
									</div>
								</div>
								<div class="col-6 text-end">
									<button id="btn-form" type="button" class="btn-style">Enregistrer</button>
								</div>
							</div>

							<div id="formulaire-client">
							</div>
						</form>
					</div>
				</div>
			</div>	
		</div>

		<div id="toast" class="">			
		</div>
	</body>
	<?php include 'footer.php'; ?>
</html>
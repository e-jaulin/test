<?php
header('Content-Type: application/json');

// Autoriser uniquement les requêtes POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); // Méthode non autorisée
    echo json_encode(["error" => "Seules les requêtes POST sont autorisées."]);
    exit;
}

// Lire le corps de la requête
$data = json_decode(file_get_contents('php://input'), true);

// Vérifier que le paramètre packageName est présent
if (!isset($data['packageName']) || empty($data['packageName'])) {
    http_response_code(400); // Mauvaise requête
    echo json_encode(["error" => "Le nom du package (packageName) est requis."]);
    exit;
}

$packageName = escapeshellarg($data['packageName']); // Sécuriser le nom du package

// Construire la commande dtexec
$command = "dtexec /F \"C:\\Chemin\\Vers\\Packages\\$packageName\"";

// Exécuter la commande
exec($command, $output, $statusCode);

if ($statusCode !== 0) {
    http_response_code(500); // Erreur interne
    echo json_encode([
        "error" => "Erreur lors de l'exécution du package.",
        "details" => implode("\n", $output)
    ]);
} else {
    echo json_encode([
        "message" => "Package exécuté avec succès.",
        "output" => implode("\n", $output)
    ]);
}
?>
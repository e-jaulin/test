<div class="bg-dark p-3 text-center position-relative">
    <h1 class="text-white">Atoptima | Lanceur de package SSIS</h1>
    <select id="versionSelect" style="position: absolute; right: 0; top: 50%; transform: translateY(-50%);width:fit-content" class="form-select">
        <option value="v1">1.0</option>
        <option value="v2">2.0</option>
        <option value="v2_1" selected>2.1</option>
    </select>
</div>

<nav id="navbar" class="navbar d-none">
    <div class="row w-100 m-0">
        <div class="col-6 mx-auto text-start">
            <button id="btn-retour" class="btn-nav" data-screen="accueil"><i data-feather="home"></i>
            <span id="nom-depot" class="text-center d-none ms-2"></span></button>            
        </div>
        <div class="col-6 mx-auto text-end">
            <button id="btn-etape1" class="btn-nav btn-selected" data-screen="etape1">Commandes</button>
            <button id="btn-client" class="btn-nav" data-screen="client">Clients</button>
            <button id="btn-etape2" class="btn-nav" data-screen="etape2">Titre étape 2</button>
        </div>               
    </div>
</nav>